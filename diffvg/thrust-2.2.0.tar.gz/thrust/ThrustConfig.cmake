# Minimal Thrust CMake configuration file
# This file provides the necessary variables for find_package(Thrust)

set(Thrust_FOUND TRUE)
set(Thrust_VERSION 2.0.0)

# Set the include directory to the thrust folder itself
set(THRUST_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}")

# Create the Thrust::Thrust target for compatibility
add_library(Thrust INTERFACE)
target_include_directories(Thrust INTERFACE "${THRUST_INCLUDE_DIR}")

# Also provide Thrust::Thrust as an alias for compatibility
add_library(Thrust::Thrust ALIAS Thrust)
