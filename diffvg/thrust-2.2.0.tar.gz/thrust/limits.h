// Copyright (c) 2018 NVIDIA Corporation
// Author: Bryce Adelstein Lelbach <brycelelbach@gmail.com>
//
// Distributed under the Boost Software License v1.0 (boost.org/LICENSE_1_0.txt)

#pragma once

#include <float.h>
#include <climits>

#include <thrust/detail/config.h>
#include <thrust/detail/type_traits.h>

THRUST_NAMESPACE_BEGIN

namespace detail {
    union FloatNaN {
        float f;
        unsigned int i;
    };
    
    union DoubleNaN {
        double d;
        unsigned long long i;
    };
}

template <typename T>
struct numeric_limits
{
    static const bool is_specialized = false;
    static T min() { return T(); }
    static T max() { return T(); }
    static const int digits = 0;
    static const int digits10 = 0;
    static const bool is_signed = false;
    static const bool is_integer = false;
    static const bool is_exact = false;
    static const int radix = 0;
    static T epsilon() { return T(); }
    static T round_error() { return T(); }
    static const int min_exponent = 0;
    static const int min_exponent10 = 0;
    static const int max_exponent = 0;
    static const int max_exponent10 = 0;
    static const bool has_infinity = false;
    static const bool has_quiet_NaN = false;
    static const bool has_signaling_NaN = false;
    static const int has_denorm = 0;
    static const bool has_denorm_loss = false;
    static T infinity() { return T(); }
    static T quiet_NaN() { return T(); }
    static T signaling_NaN() { return T(); }
    static T denorm_min() { return T(); }
    static const bool is_iec559 = false;
    static const bool is_bounded = false;
    static const bool is_modulo = false;
    static const bool traps = false;
    static const bool tinyness_before = false;
    static const int round_style = 0;
};

template <>
struct numeric_limits<float>
{
    static const bool is_specialized = true;
    static float min() { return FLT_MIN; }
    static float max() { return FLT_MAX; }
    static const int digits = FLT_MANT_DIG;
    static const int digits10 = FLT_DIG;
    static const bool is_signed = true;
    static const bool is_integer = false;
    static const bool is_exact = false;
    static const int radix = 2;
    static float epsilon() { return FLT_EPSILON; }
    static float round_error() { return 0.5f; }
    static const int min_exponent = FLT_MIN_EXP;
    static const int min_exponent10 = FLT_MIN_10_EXP;
    static const int max_exponent = FLT_MAX_EXP;
    static const int max_exponent10 = FLT_MAX_10_EXP;
    static const bool has_infinity = true;
    static const bool has_quiet_NaN = true;
    static const bool has_signaling_NaN = true;
    static const int has_denorm = 0;
    static const bool has_denorm_loss = false;
    static float infinity() { return (float)1e308 * 10.f; }
    static float quiet_NaN() { 
        detail::FloatNaN u; 
        u.i = 0x7FC00000; 
        return u.f; 
    }
    static float signaling_NaN() { 
        detail::FloatNaN u; 
        u.i = 0x7F800001; 
        return u.f; 
    }
    static float denorm_min() { return FLT_MIN; }
    static const bool is_iec559 = true;
    static const bool is_bounded = true;
    static const bool is_modulo = false;
    static const bool traps = true;
    static const bool tinyness_before = true;
    static const int round_style = 1;
};

template <>
struct numeric_limits<double>
{
    static const bool is_specialized = true;
    static double min() { return DBL_MIN; }
    static double max() { return DBL_MAX; }
    static const int digits = DBL_MANT_DIG;
    static const int digits10 = DBL_DIG;
    static const bool is_signed = true;
    static const bool is_integer = false;
    static const bool is_exact = false;
    static const int radix = 2;
    static double epsilon() { return DBL_EPSILON; }
    static double round_error() { return 0.5; }
    static const int min_exponent = DBL_MIN_EXP;
    static const int min_exponent10 = DBL_MIN_10_EXP;
    static const int max_exponent = DBL_MAX_EXP;
    static const int max_exponent10 = DBL_MAX_10_EXP;
    static const bool has_infinity = true;
    static const bool has_quiet_NaN = true;
    static const bool has_signaling_NaN = true;
    static const int has_denorm = 0;
    static const bool has_denorm_loss = false;
    static double infinity() { return 1e308 * 10.0; }
    static double quiet_NaN() { 
        detail::DoubleNaN u; 
        u.i = 0x7FF8000000000000ULL; 
        return u.d; 
    }
    static double signaling_NaN() { 
        detail::DoubleNaN u; 
        u.i = 0x7FF0000000000001ULL; 
        return u.d; 
    }
    static double denorm_min() { return DBL_MIN; }
    static const bool is_iec559 = true;
    static const bool is_bounded = true;
    static const bool is_modulo = false;
    static const bool traps = true;
    static const bool tinyness_before = true;
    static const int round_style = 1;
};

template <>
struct numeric_limits<int>
{
    static const bool is_specialized = true;
    static int min() { return INT_MIN; }
    static int max() { return INT_MAX; }
    static const int digits = CHAR_BIT * sizeof(int) - 1;
    static const int digits10 = 9;
    static const bool is_signed = true;
    static const bool is_integer = true;
    static const bool is_exact = true;
    static const int radix = 2;
    static int epsilon() { return 0; }
    static int round_error() { return 0; }
    static const int min_exponent = 0;
    static const int min_exponent10 = 0;
    static const int max_exponent = 0;
    static const int max_exponent10 = 0;
    static const bool has_infinity = false;
    static const bool has_quiet_NaN = false;
    static const bool has_signaling_NaN = false;
    static const int has_denorm = 0;
    static const bool has_denorm_loss = false;
    static int infinity() { return 0; }
    static int quiet_NaN() { return 0; }
    static int signaling_NaN() { return 0; }
    static int denorm_min() { return 0; }
    static const bool is_iec559 = false;
    static const bool is_bounded = true;
    static const bool is_modulo = true;
    static const bool traps = false;
    static const bool tinyness_before = false;
    static const int round_style = 0;
};

template <>
struct numeric_limits<unsigned int>
{
    static const bool is_specialized = true;
    static unsigned int min() { return 0; }
    static unsigned int max() { return UINT_MAX; }
    static const int digits = CHAR_BIT * sizeof(unsigned int);
    static const int digits10 = 10;
    static const bool is_signed = false;
    static const bool is_integer = true;
    static const bool is_exact = true;
    static const int radix = 2;
    static unsigned int epsilon() { return 0; }
    static unsigned int round_error() { return 0; }
    static const int min_exponent = 0;
    static const int min_exponent10 = 0;
    static const int max_exponent = 0;
    static const int max_exponent10 = 0;
    static const bool has_infinity = false;
    static const bool has_quiet_NaN = false;
    static const bool has_signaling_NaN = false;
    static const int has_denorm = 0;
    static const bool has_denorm_loss = false;
    static unsigned int infinity() { return 0; }
    static unsigned int quiet_NaN() { return 0; }
    static unsigned int signaling_NaN() { return 0; }
    static unsigned int denorm_min() { return 0; }
    static const bool is_iec559 = false;
    static const bool is_bounded = true;
    static const bool is_modulo = true;
    static const bool traps = false;
    static const bool tinyness_before = false;
    static const int round_style = 0;
};

template <>
struct numeric_limits<long long>
{
    static const bool is_specialized = true;
    static long long min() { return LLONG_MIN; }
    static long long max() { return LLONG_MAX; }
    static const int digits = CHAR_BIT * sizeof(long long) - 1;
    static const int digits10 = 18;
    static const bool is_signed = true;
    static const bool is_integer = true;
    static const bool is_exact = true;
    static const int radix = 2;
    static long long epsilon() { return 0; }
    static long long round_error() { return 0; }
    static const int min_exponent = 0;
    static const int min_exponent10 = 0;
    static const int max_exponent = 0;
    static const int max_exponent10 = 0;
    static const bool has_infinity = false;
    static const bool has_quiet_NaN = false;
    static const bool has_signaling_NaN = false;
    static const int has_denorm = 0;
    static const bool has_denorm_loss = false;
    static long long infinity() { return 0; }
    static long long quiet_NaN() { return 0; }
    static long long signaling_NaN() { return 0; }
    static long long denorm_min() { return 0; }
    static const bool is_iec559 = false;
    static const bool is_bounded = true;
    static const bool is_modulo = true;
    static const bool traps = false;
    static const bool tinyness_before = false;
    static const int round_style = 0;
};

THRUST_NAMESPACE_END
